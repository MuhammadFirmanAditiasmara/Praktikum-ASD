public class KuisMain18 {
    public static final double nilaiUTS18 = 0;
        public static double nilaiKuis18;
        
            public static void main(String[] args) {
                Kuis18 nilai1  = new Kuis18();
        
                nilai1.nim18 = "2411";
                nilai1.nama18 = "Endra";
                nilai1.nilaiKuis18 = 73.4;
                nilai1.nilaiUTS18 = 88.4;
                nilai1.nilaiUAS18 = 82.9;
                nilai1.tampilkanInformasi();
                
                
               
        
        Kuis18 nilai2  = new Kuis18();
        nilai2.nim18 = "2468";
        nilai2.nama18 = "Lely";
        nilai2.nilaiKuis18 = 80.1;
        nilai2.nilaiUTS18 = 85.9;
        nilai2.nilaiUAS18 = 79.6;
        nilai2.tampilkanInformasi();
        
        Kuis18 nilai3  = new Kuis18();
        
        nilai3.nim18 = "2473";
        nilai3.nama18 = "Yuni";
        nilai3.nilaiKuis18 = 91.2;
        nilai3.nilaiUTS18 = 90.3;
        nilai3.nilaiUAS18 = 85.3;
        nilai3.tampilkanInformasi();
        
        Kuis18 nilai4  = new Kuis18();
        
        nilai4.nim18 = "2479";
        nilai4.nama18 = "Roma";
        nilai4.nilaiKuis18 = 88.5;
        nilai4.nilaiUTS18 = 88.4;
        nilai4.nilaiUAS18 = 80.2;
        nilai4.tampilkanInformasi();
        
    }
}
